using System.Data;

namespace WinFormsApp1
{
    public partial class Form1 : Form

    {
        DataTable Table;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Table = new DataTable();
            Table.Columns.Add("Title", typeof(String));
            Table.Columns.Add("Messages", typeof(String));

            dataGridView1.DataSource = Table;


        }





        private void button4_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox1.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Table.Rows.Add(textBox1.Text, textBox2.Text);
            textBox2.Clear();
            textBox1.Clear();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            int Index = dataGridView1.CurrentCell.RowIndex;

            Table.Rows[Index].Delete();

        }
    }
}
